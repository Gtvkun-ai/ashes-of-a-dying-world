using Godot;
using AshesofaDyingWorld.Combat.Actors;
using AshesofaDyingWorld.Combat.Data;
using AshesofaDyingWorld.Combat.Decision.Model;
using AshesofaDyingWorld.Combat.Model;
using AshesofaDyingWorld.Combat.Runtime;

namespace AshesofaDyingWorld.Combat.Decision.Runtime
{
    /// <summary>
    /// Cổng duy nhất đọc thế giới cho Decision Core.
    /// Những sensor chưa tồn tại vẫn để false thay vì bịa dữ liệu, nhưng resource pool
    /// được chụp đầy đủ để phân biệt "không có mana" và "đã cạn mana".
    /// </summary>
    public sealed class CombatPerception : ICombatPerception
    {
        private readonly SceneTree _tree;
        private readonly RayCast2D _lineOfSightRay;
        private readonly CombatLineOfFireSensor _lineOfFireSensor;
        private readonly ProjectileSpecData _primaryProjectileSpec;
        private readonly IThreatPredictor _threatPredictor;
        private readonly float _enemySearchRadius;
        private readonly float _leaderDangerRadius;

        public CombatPerception(
            SceneTree tree,
            RayCast2D lineOfSightRay,
            CombatLineOfFireSensor lineOfFireSensor,
            ProjectileSpecData primaryProjectileSpec,
            IThreatPredictor threatPredictor,
            float enemySearchRadius,
            float leaderDangerRadius)
        {
            _tree = tree;
            _lineOfSightRay = lineOfSightRay;
            _lineOfFireSensor = lineOfFireSensor;
            _primaryProjectileSpec = primaryProjectileSpec;
            _threatPredictor = threatPredictor;
            _enemySearchRadius = Mathf.Max(1f, enemySearchRadius);
            _leaderDangerRadius = Mathf.Max(1f, leaderDangerRadius);
        }

        public CombatSnapshot BuildSnapshot(
            CombatCharacter self,
            CombatCharacter leader,
            CombatRoleAssignment? assignment,
            CombatBlackboard blackboard,
            float timeSeconds)
        {
            CombatCharacter target = ResolveTarget(self, assignment, blackboard);
            bool hasTarget = IsUsable(target) && target.IsAlive;
            Vector2 targetPosition = hasTarget ? target.CombatCenter : blackboard.LastKnownTargetPosition;
            Vector2 toTarget = hasTarget ? targetPosition - self.CombatCenter : Vector2.Zero;
            float targetDistance = toTarget.Length();
            Vector2 directionToTarget = targetDistance > 0.001f
                ? toTarget / targetDistance
                : Vector2.Zero;

            bool hasLineOfSight = hasTarget && HasLineOfSight(self, target);
            bool targetFacingSelf = hasTarget
                && directionToTarget != Vector2.Zero
                && target.FacingDirection.Dot(-directionToTarget) >= 0.35f;
            CombatStateId? targetState = hasTarget && target.StateMachine != null
                ? target.StateMachine.Current
                : null;
            bool targetInRecovery = targetState == CombatStateId.AttackRecovery;
            bool targetIsCasting = hasTarget
                && target.Actions?.CurrentAction?.DeliveryMode == CombatDeliveryMode.Projectile;

            ThreatAssessment threat = hasTarget
                ? _threatPredictor.EvaluateThreats(self, target, targetDistance)
                : ThreatAssessment.None;

            if (hasTarget)
            {
                blackboard.CurrentTargetId = target.GetInstanceId();
                blackboard.LastKnownTargetPosition = targetPosition;
                if (hasLineOfSight)
                {
                    blackboard.LastSeenTargetTime = Mathf.Max(0f, timeSeconds);
                }
            }
            else
            {
                blackboard.CurrentTargetId = null;
            }

            bool hasLeader = IsUsable(leader) && leader.IsAlive;
            Vector2 leaderPosition = hasLeader ? leader.CombatCenter : Vector2.Zero;
            float distanceToLeader = hasLeader
                ? self.CombatCenter.DistanceTo(leaderPosition)
                : 0f;
            bool leaderThreatened = hasLeader && IsActorThreatened(leader, _leaderDangerRadius);

            // Với bộ kỹ năng hiện có, chạy nhanh chính là dodge. Perception chỉ cung cấp
            // hướng thoát an toàn tương đối; movement solver vẫn chịu trách nhiệm tránh vật cản.
            Vector2 safeRetreatVector = Vector2.Zero;
            bool hasSafeRetreatVector = false;
            if (hasTarget && directionToTarget.LengthSquared() > 0.001f)
            {
                Vector2 tangent = new Vector2(-directionToTarget.Y, directionToTarget.X)
                    * (blackboard.OrbitSide < 0 ? -1f : 1f);
                safeRetreatVector = (-directionToTarget * 0.86f + tangent * 0.52f).Normalized();
                hasSafeRetreatVector = safeRetreatVector.LengthSquared() > 0.001f;
            }

            var health = new CombatResourceSnapshot(self.Stats?.CurrentHP ?? 0f, self.Stats?.MaxHP ?? 0f);
            var mana = new CombatResourceSnapshot(self.Stats?.CurrentMP ?? 0f, self.Stats?.MaxMP ?? 0f);
            var stamina = new CombatResourceSnapshot(self.Stats?.CurrentStamina ?? 0f, self.Stats?.MaxStamina ?? 0f);
            var guard = new CombatResourceSnapshot(self.Stats?.CurrentGuard ?? 0f, self.Stats?.MaxGuard ?? 0f);
            var poise = new CombatResourceSnapshot(self.Stats?.CurrentPoise ?? 0f, self.Stats?.MaxPoise ?? 0f);

            CombatStateMachine stateMachine = self.StateMachine;
            bool canMove = stateMachine?.CanMove ?? false;
            bool canBlock = (stateMachine?.CanStartBlock ?? false)
                && guard.HasPool
                && guard.Current > 0.001f;
            bool canStartAction = stateMachine?.CanStartAttack ?? false;

            return new CombatSnapshot(
                self.GetInstanceId(),
                self.CombatCenter,
                stateMachine?.Current ?? CombatStateId.Locomotion,
                health,
                mana,
                stamina,
                guard,
                poise,
                canMove,
                canBlock,
                canStartAction,
                hasTarget ? target.GetInstanceId() : null,
                targetPosition,
                targetDistance,
                directionToTarget,
                hasLineOfSight,
                targetFacingSelf,
                targetInRecovery,
                targetIsCasting,
                targetState,
                threat.EtaSeconds,
                threat.Severity,
                threat.Blockable,
                threat.Dodgeable,
                hasLeader ? leader.GetInstanceId() : null,
                leaderPosition,
                distanceToLeader,
                leaderThreatened,
                hasSafeRetreatVector,
                safeRetreatVector,
                false,
                false,
                timeSeconds);
        }

        private CombatCharacter ResolveTarget(
            CombatCharacter self,
            CombatRoleAssignment? assignment,
            CombatBlackboard blackboard)
        {
            if (assignment.HasValue)
            {
                CombatCharacter assigned = assignment.Value.PriorityTarget;
                if (IsValidHostile(self, assigned, _enemySearchRadius * 1.5f))
                {
                    return assigned;
                }
            }

            // Hysteresis mục tiêu: giữ target hiện tại xa hơn search radius một chút,
            // tránh flip giữa hai quái chỉ vì chênh vài pixel.
            if (blackboard.CurrentTargetId.HasValue)
            {
                CombatCharacter remembered = FindCombatantById(blackboard.CurrentTargetId.Value);
                if (IsValidHostile(self, remembered, _enemySearchRadius * 1.25f))
                {
                    return remembered;
                }
            }

            CombatCharacter nearest = null;
            float bestDistanceSquared = _enemySearchRadius * _enemySearchRadius;
            if (_tree == null)
            {
                return null;
            }

            foreach (Node node in _tree.GetNodesInGroup("Combatant"))
            {
                if (node is not CombatCharacter candidate
                    || !IsValidHostile(self, candidate, _enemySearchRadius))
                {
                    continue;
                }

                float distanceSquared = self.CombatCenter.DistanceSquaredTo(candidate.CombatCenter);
                if (distanceSquared >= bestDistanceSquared)
                {
                    continue;
                }

                nearest = candidate;
                bestDistanceSquared = distanceSquared;
            }

            return nearest;
        }

        private CombatCharacter FindCombatantById(ulong instanceId)
        {
            if (_tree == null)
            {
                return null;
            }

            foreach (Node node in _tree.GetNodesInGroup("Combatant"))
            {
                if (node is CombatCharacter combatant && combatant.GetInstanceId() == instanceId)
                {
                    return combatant;
                }
            }

            return null;
        }

        private bool IsActorThreatened(CombatCharacter actor, float radius)
        {
            if (_tree == null || !IsUsable(actor))
            {
                return false;
            }

            float radiusSquared = radius * radius;
            foreach (Node node in _tree.GetNodesInGroup("Combatant"))
            {
                if (node is not CombatCharacter hostile
                    || hostile == actor
                    || !hostile.IsAlive
                    || !FactionRules.IsHostile(hostile.Faction, actor.Faction))
                {
                    continue;
                }

                float distanceSquared = actor.CombatCenter.DistanceSquaredTo(hostile.CombatCenter);
                if (distanceSquared > radiusSquared || hostile.StateMachine == null)
                {
                    continue;
                }

                CombatStateId state = hostile.StateMachine.Current;
                if (state != CombatStateId.AttackStartup && state != CombatStateId.AttackActive)
                {
                    continue;
                }

                Vector2 toActor = actor.CombatCenter - hostile.CombatCenter;
                if (toActor.LengthSquared() > 0.001f
                    && hostile.FacingDirection.Dot(toActor.Normalized()) >= 0.25f)
                {
                    return true;
                }
            }

            return false;
        }

        public bool HasLineOfSight(CombatCharacter self, CombatCharacter target)
        {
            if (!IsUsable(self) || !IsUsable(target))
            {
                return false;
            }

            // Với ranged AI, "thấy mục tiêu" thực tế phải có nghĩa là viên đạn thật đi tới được mục tiêu.
            // ShapeCast dùng cùng bán kính/mask với projectile nên cây, tường và đồng đội đều có ý nghĩa.
            if (_lineOfFireSensor != null && GodotObject.IsInstanceValid(_lineOfFireSensor))
            {
                LineOfFireResult line = _lineOfFireSensor.Query(self, target, _primaryProjectileSpec);
                if (line.IsValid)
                {
                    return line.ReachesTarget;
                }
            }

            // Fallback cho actor/class chưa có projectile profile. Ray này chỉ dùng world LOS;
            // không còn bỏ qua đồng minh bằng policy cũ vì friendly fire hiện là luật vật lý thật.
            if (_lineOfSightRay == null || !GodotObject.IsInstanceValid(_lineOfSightRay))
            {
                return false;
            }

            _lineOfSightRay.ClearExceptions();
            _lineOfSightRay.TargetPosition = _lineOfSightRay.ToLocal(target.CombatCenter);
            _lineOfSightRay.ForceRaycastUpdate();
            if (!_lineOfSightRay.IsColliding())
            {
                return true;
            }

            GodotObject collider = _lineOfSightRay.GetCollider();
            if (collider == target)
            {
                return true;
            }

            return collider is Node colliderNode && target.IsAncestorOf(colliderNode);
        }

        private static bool IsValidHostile(CombatCharacter self, CombatCharacter candidate, float radius)
        {
            return IsUsable(candidate)
                && candidate != self
                && candidate.IsAlive
                && FactionRules.IsHostile(self.Faction, candidate.Faction)
                && self.CombatCenter.DistanceSquaredTo(candidate.CombatCenter) <= radius * radius;
        }

        private static bool IsUsable(Node node)
        {
            return node != null
                && GodotObject.IsInstanceValid(node)
                && !node.IsQueuedForDeletion();
        }
    }
}
