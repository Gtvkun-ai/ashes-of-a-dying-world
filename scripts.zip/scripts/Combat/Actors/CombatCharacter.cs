using Godot;
using AshesofaDyingWorld.Combat.Data;
using AshesofaDyingWorld.Combat.Model;
using AshesofaDyingWorld.Combat.Projectiles;
using AshesofaDyingWorld.Combat.Runtime;
using AshesofaDyingWorld.Combat.Visuals;
using AshesofaDyingWorld.Core.Data;
using AshesofaDyingWorld.Core.Managers;
using AshesofaDyingWorld.Entities.Player;
using AshesofaDyingWorld.UI.HUD;
using AshesofaDyingWorld.World.Maps;

namespace AshesofaDyingWorld.Combat.Actors
{
    /// <summary>
    /// Lõi chung của Player, companion và enemy.
    /// Mọi actor chỉ khác nguồn intent và AI, không còn mỗi class tự phát minh damage/block/knockback.
    /// </summary>
    public abstract partial class CombatCharacter : CharacterBody2D
    {
        [Signal] public delegate void HitResolvedEventHandler(float hpDamage, bool blocked, bool guardBroken);
        [Signal] public delegate void DefeatedEventHandler(Node attacker);

        [ExportGroup("Combat Identity")]
        [Export] public string CombatantId { get; set; } = "combatant";
        [Export] public CombatFaction Faction { get; set; } = CombatFaction.Neutral;
        [Export] public bool RemoveFromWorldOnDeath { get; set; } = false;
        [Export] public WeaponMovesetData DefaultMoveset { get; set; }

        [ExportGroup("Scene Bindings")]
        [Export] public NodePath BodyPath { get; set; } = new NodePath("Body");
        [Export] public NodePath StatsPath { get; set; } = new NodePath("PlayerStats");
        [Export] public NodePath EquipmentPath { get; set; } = new NodePath("EquipmentManager");
        [Export] public NodePath HurtboxPath { get; set; } = new NodePath("Hurtbox");
        [Export] public NodePath WeaponSpritePath { get; set; } = new NodePath("WeaponSprite");

        [ExportGroup("Movement")]
        [Export] public float Speed { get; set; } = 100f;
        [Export] public float RunSpeed { get; set; } = 180f;
        [Export] public float RunStaminaCost { get; set; } = 12f;
        [Export] public float MinStaminaToRun { get; set; } = 10f;
        [Export] public float Acceleration { get; set; } = 1200f;
        [Export] public float Deceleration { get; set; } = 1600f;
        [Export] public float ExternalForceDecay { get; set; } = 900f;
        [Export] public float ActionLungeMultiplier { get; set; } = 1f;
        [Export] public int StopFrameIndex { get; set; } = 0;

        [ExportGroup("World Safety")]
        [Export] public bool KeepInsideLevelBounds { get; set; } = true;
        [Export] public float LevelBoundsInset { get; set; } = 18f;
        [Export] public float LevelBoundsRefreshSeconds { get; set; } = 0.5f;

        public PlayerStats Stats { get; private set; }
        public EquipmentManager Equipment { get; private set; }
        public CombatStateMachine StateMachine { get; private set; }
        public CombatActionRunner Actions { get; private set; }
        public CombatAbilityRunner Abilities { get; private set; }
        public CombatStatusController Statuses { get; private set; }
        public float RuntimeAttackSpeedMultiplier => Statuses?.AttackSpeedMultiplier ?? 1f;
        public AnimatedSprite2D BodySprite => _body;
        public bool IsAlive => Stats == null || Stats.CurrentHP > 0f;
        public bool IsBlocking => StateMachine?.Current == CombatStateId.Blocking;
        public bool IsPerfectParryWindowActive => _parryWindowRemaining > 0f;
        public bool IsCounterAttackReady => _counterAttackWindowRemaining > 0f;
        public bool IsPerformingAttack => Actions?.IsRunning == true;
        public Vector2 FacingDirection => DirectionToVector(_facingCardinal);
        public string FacingCardinal => _facingCardinal;
        public Vector2 CombatCenter => _hurtboxShape != null
            && GodotObject.IsInstanceValid(_hurtboxShape)
                ? _hurtboxShape.GlobalPosition
                : (_hurtbox?.GlobalPosition ?? GlobalPosition);

        public WeaponMovesetData ActiveMoveset
        {
            get
            {
                EquipmentItemData weapon = Equipment?.GetEquippedItem(EquipmentSlot.MainHand);
                return weapon?.Moveset ?? DefaultMoveset;
            }
        }

        private AnimatedSprite2D _body;
        private AnimatedSprite2D _weaponSprite;
        private Area2D _hurtbox;
        private CollisionShape2D _hurtboxShape;
        private CombatHitbox _combatHitbox;
        private Vector2 _moveCommand;
        private bool _runCommand;
        private bool _isActuallyRunning;
        private float _moveSpeedScale = 1f;
        private bool _preserveFacingWhileMoving;
        private bool _blockCommand;
        private float _parryWindowRemaining;
        private float _counterAttackWindowRemaining;
        private bool _isExhausted;
        private Vector2 _locomotionVelocity;
        private Vector2 _externalVelocity;
        private string _facingCardinal = "down";
        private string _lastMoveAnimation = "go_down";
        private bool _wasMoving;
        private bool _isResolvingHit;
        private bool _defeatHandled;
        private float _impactFreezeRemaining;
        private float _storedBodySpeedScale = 1f;
        private bool _bodySpeedFrozen;
        private float _hitFlashRemaining;
        private Color _baseBodySelfModulate = Colors.White;
        private Vector2 _baseBodyPosition = Vector2.Zero;
        private float _launchRemaining;
        private float _launchDuration;
        private float _launchHeight;
        private CombatFreezeVfx2D _freezeStatusVfx;
        private Rect2 _levelBounds;
        private bool _hasLevelBounds;
        private float _levelBoundsRefreshRemaining;
        private ulong _levelBoundsSceneId;

        public override void _Ready()
        {
            AddToGroup("Combatant");
            ConfigureFactionGroups();
            ResolveCoreNodes();

            StateMachine = new CombatStateMachine();
            StateMachine.StateChanged += OnCombatStateChanged;

            _combatHitbox = new CombatHitbox();
            _combatHitbox.Initialize(this);
            // _Ready của CharacterBody2D vẫn có thể nằm trong pha Godot đang dựng child.
            // Attach runtime node ở deferred frame để tránh "Parent node is busy setting up children".
            CallDeferred("add_child", _combatHitbox);

            Actions = new CombatActionRunner(this, _body, _combatHitbox, StateMachine);
            Actions.ActionReleased += OnActionReleased;
            Actions.ActionEventTriggered += OnActionEventTriggered;
            Abilities = new CombatAbilityRunner(this);
            Statuses = new CombatStatusController();

            if (_body != null)
            {
                _baseBodySelfModulate = _body.SelfModulate;
                _baseBodyPosition = _body.Position;
                _body.FrameChanged += OnBodyFrameChanged;
                _body.AnimationFinished += OnBodyAnimationFinished;
                PlayIdleFrame();
            }

            if (Equipment != null)
            {
                Equipment.WeaponVisualChanged += OnWeaponVisualChanged;
            }

            if (Stats != null)
            {
                Stats.Defeated += OnStatsDefeated;
            }

            OnCombatReady();
        }

        public override void _PhysicsProcess(double delta)
        {
            float dt = (float)delta;
            if (StateMachine == null)
            {
                return;
            }

            UpdateLevelBoundsCache(dt);
            Statuses?.Update(dt);
            UpdateStatusVisualEffects();
            UpdateImpactPresentation(dt);
            if (_impactFreezeRemaining > 0f)
            {
                Velocity = Vector2.Zero;
                EnforceLevelBounds();
                return;
            }

            Abilities?.Update(dt);
            UpdateDefenseWindows(dt);
            UpdateControlSource(dt);
            StateMachine.Tick(dt);
            Actions?.Update(dt);
            SynchronizeBlocking();
            UpdateMovement(dt);
            UpdateAnimation();

            Stats?.UpdateRegeneration(
                dt,
                StateMachine.CanRegenerateStamina && !_isActuallyRunning,
                StateMachine.CanRegenerateGuard,
                StateMachine.CanRegeneratePoise,
                StateMachine.CanRegenerateMana);

            MoveAndSlide();
            EnforceLevelBounds();
            _wasMoving = _locomotionVelocity.LengthSquared() > 1f;
        }

        public override void _ExitTree()
        {
            if (Equipment != null)
            {
                Equipment.WeaponVisualChanged -= OnWeaponVisualChanged;
            }

            if (Stats != null)
            {
                Stats.Defeated -= OnStatsDefeated;
            }

            if (_body != null)
            {
                _body.FrameChanged -= OnBodyFrameChanged;
                _body.AnimationFinished -= OnBodyAnimationFinished;
            }

            if (StateMachine != null)
            {
                StateMachine.StateChanged -= OnCombatStateChanged;
            }

            if (Actions != null)
            {
                Actions.ActionReleased -= OnActionReleased;
                Actions.ActionEventTriggered -= OnActionEventTriggered;
            }

            Abilities?.Clear();
            if (_freezeStatusVfx != null && GodotObject.IsInstanceValid(_freezeStatusVfx))
            {
                _freezeStatusVfx.QueueFree();
                _freezeStatusVfx = null;
            }
            OnCombatExitTree();
        }

        /// <summary>
        /// Đặt hướng di chuyển. preserveFacing = true dùng cho strafe/backpedal trong combat:
        /// nhân vật vẫn nhìn mục tiêu dù đang lùi hoặc đi ngang.
        ///
        /// speedScale cho phép motor giảm tốc mượt khi tới formation anchor. Trước đây mọi lệnh
        /// chỉ có 0 hoặc 100% tốc độ, nên companion liên tục vượt điểm dừng rồi quay lại.
        /// </summary>
        public void SetMoveInput(
            Vector2 direction,
            bool wantsRun = false,
            bool preserveFacing = false,
            float speedScale = 1f)
        {
            _moveCommand = direction == Vector2.Zero ? Vector2.Zero : direction.Normalized();
            _runCommand = wantsRun && _moveCommand != Vector2.Zero;
            _moveSpeedScale = _moveCommand == Vector2.Zero
                ? 1f
                : Mathf.Clamp(speedScale, 0.08f, 1f);
            _preserveFacingWhileMoving = preserveFacing && _moveCommand != Vector2.Zero;
        }

        public void StopMoveInput()
        {
            SetMoveInput(Vector2.Zero, false, false);
        }

        /// <summary>
        /// Giữ target/anchor AI trong hình chữ nhật playable của level.
        /// Navigation vẫn xử lý vật cản bên trong map; đây chỉ là safety rail ở mép ngoài.
        /// </summary>
        public Vector2 ClampWorldPointToLevelBounds(Vector2 worldPoint, float extraInset = 0f)
        {
            if (!KeepInsideLevelBounds || !_hasLevelBounds)
            {
                return worldPoint;
            }

            float inset = Mathf.Max(0f, LevelBoundsInset + extraInset);
            float minX = _levelBounds.Position.X + inset;
            float minY = _levelBounds.Position.Y + inset;
            float maxX = _levelBounds.End.X - inset;
            float maxY = _levelBounds.End.Y - inset;

            if (maxX < minX || maxY < minY)
            {
                return worldPoint;
            }

            return new Vector2(
                Mathf.Clamp(worldPoint.X, minX, maxX),
                Mathf.Clamp(worldPoint.Y, minY, maxY));
        }

        public void SetBlocking(bool value)
        {
            bool wantsBlock = value && Statuses?.IsFrozen != true;
            bool blockPressed = wantsBlock && !_blockCommand;
            _blockCommand = wantsBlock;

            if (blockPressed)
            {
                WeaponMovesetData moveset = ActiveMoveset;
                _parryWindowRemaining = moveset?.PerfectParryEnabled == true
                    ? Mathf.Clamp(moveset.PerfectParryWindowSeconds, 0.10f, 0.16f)
                    : 0f;
            }
            else if (!wantsBlock)
            {
                _parryWindowRemaining = 0f;
            }
        }

        public void ReleaseBlock()
        {
            _blockCommand = false;
            _parryWindowRemaining = 0f;
            StateMachine?.EndBlock();
        }

        public bool RequestAttack()
        {
            if (!IsAlive || Statuses?.IsFrozen == true)
            {
                return false;
            }

            bool counterReady = _counterAttackWindowRemaining > 0f;
            bool restoreBlockOnFailure = counterReady && _blockCommand;
            if (counterReady && StateMachine?.Current == CombatStateId.Blocking)
            {
                // Perfect parry mở một cancel thật từ guard sang light attack. Không cần thả
                // nút block trước rồi bấm attack ở frame kế tiếp như đang điền biểu mẫu hành chính.
                _blockCommand = false;
                _parryWindowRemaining = 0f;
                StateMachine.EndBlock();
            }

            bool accepted = Actions?.RequestLightAttack() == true;
            if (accepted && counterReady)
            {
                _counterAttackWindowRemaining = 0f;
                _blockCommand = false;
            }
            else if (!accepted && restoreBlockOnFailure)
            {
                _blockCommand = true;
            }

            return accepted;
        }

        public void FaceToward(Vector2 worldPosition)
        {
            // Dùng CombatCenter thay vì root GlobalPosition. Hurtbox của nhiều actor có offset,
            // nếu trừ từ root thì một vector "up" ngắn có thể bị offset kéo thành "down".
            Vector2 direction = worldPosition - CombatCenter;
            FaceDirection(direction);
        }

        public void FaceDirection(Vector2 direction)
        {
            if (direction.LengthSquared() <= 0.001f)
            {
                return;
            }

            _facingCardinal = ResolveCardinalDirection(direction.Normalized());
            _lastMoveAnimation = $"go_{_facingCardinal}";
        }

        public void ApplyExternalForce(Vector2 force, float animLockTime = -1f)
        {
            _externalVelocity += force;
            if (animLockTime > 0f && StateMachine?.Current != CombatStateId.Dead)
            {
                StateMachine.EnterHitstun(animLockTime);
            }
        }

        public bool IsBlockingAttackFrom(Vector2 attackerPosition)
        {
            if (!IsBlocking || !IsAlive || (Stats != null && Stats.CurrentGuard <= 0f))
            {
                return false;
            }

            Vector2 toAttacker = (attackerPosition - GlobalPosition).Normalized();
            if (toAttacker == Vector2.Zero)
            {
                return true;
            }

            float guardArc = ActiveMoveset?.GuardArcDegrees ?? 140f;
            float minimumDot = Mathf.Cos(Mathf.DegToRad(Mathf.Clamp(guardArc, 1f, 360f) * 0.5f));
            return FacingDirection.Dot(toAttacker) >= minimumDot;
        }

        public HitResult TryResolveHit(CombatCharacter target, CombatActionData action, HitProfileData profile)
        {
            Vector2 direction = target == null
                ? FacingDirection
                : (target.CombatCenter - CombatCenter).Normalized();
            return TryResolveHit(target, action, profile, CombatCenter, direction, 1f);
        }

        /// <summary>
        /// Overload cho projectile: block arc và knockback phải dựa trên điểm va chạm/hướng bay,
        /// không phải vị trí caster đã chạy sang chỗ khác sau khi bắn.
        /// </summary>
        public HitResult TryResolveHit(
            CombatCharacter target,
            CombatActionData action,
            HitProfileData profile,
            Vector2 hitOrigin,
            Vector2 attackDirection,
            float damageMultiplier = 1f)
        {
            if (target == null || profile == null)
            {
                return HitResult.Rejected(HitRejectionReason.InvalidRequest);
            }

            Vector2 safeDirection = attackDirection.LengthSquared() <= 0.001f
                ? (target.CombatCenter - hitOrigin).Normalized()
                : attackDirection.Normalized();
            return target.ReceiveHit(new HitRequest
            {
                Attacker = this,
                Target = target,
                Action = action,
                Profile = profile,
                DamageMultiplier = Mathf.Max(0f, damageMultiplier),
                HitOrigin = hitOrigin,
                AttackDirection = safeDirection
            });
        }

        public virtual HitResult ReceiveHit(HitRequest request)
        {
            if (TryPerfectParry(request, out HitResult parryResult))
            {
                return parryResult;
            }

            _isResolvingHit = true;
            HitResult result;
            try
            {
                result = CombatResolver.Resolve(request);
            }
            finally
            {
                _isResolvingHit = false;
            }

            if (!result.Applied)
            {
                return result;
            }

            if (result.Shattered)
            {
                Statuses?.ConsumeFrozenForShatter();
            }

            bool canApplyStatus = !result.WasBlocked || result.GuardBroken;
            CombatStatusController.ApplicationResult statusResult = request?.Profile != null && canApplyStatus
                ? Statuses?.Apply(request.Profile) ?? default
                : default;

            if (result.Killed)
            {
                Actions?.Cancel();
                Abilities?.CancelActiveEffects();
                Statuses?.Clear();
                StateMachine.EnterDead();
            }
            else if (statusResult.FreezeStarted)
            {
                Actions?.Cancel();
                _blockCommand = false;
                StateMachine.EnterHitstun(Mathf.Max(0.05f, request.Profile.FreezeSeconds));
            }
            else if (result.GuardBroken)
            {
                Actions?.Cancel();
                _blockCommand = false;
                StateMachine.EnterGuardBreak(0.75f);
            }
            else if (result.Staggered)
            {
                Actions?.Cancel();
                float staggerSeconds = result.ForcedStaggerSeconds > 0f
                    ? result.ForcedStaggerSeconds
                    : 0.42f;
                StateMachine.EnterStagger(staggerSeconds);
            }
            else if (result.WasBlocked)
            {
                StateMachine.EnterBlockStun(0.1f);
            }
            else if (result.HitstunSeconds > 0f)
            {
                Actions?.Cancel();
                StateMachine.EnterHitstun(result.HitstunSeconds);
            }

            if (result.Knockback != Vector2.Zero && (!result.WasBlocked || result.GuardBroken))
            {
                _externalVelocity += result.Knockback;
            }

            if (result.LaunchHeight > 0f && !result.Killed && (!result.WasBlocked || result.GuardBroken))
            {
                StartVisualLaunch(result.LaunchHeight, result.LaunchDuration);
            }

            if (result.HitFlashSeconds > 0f && !result.Killed)
            {
                BeginHitFlash(result.HitFlashSeconds);
            }

            bool hitStopEnabled = SettingsManager.Instance?.CurrentSettings?.HitStopEnabled ?? true;
            if (hitStopEnabled && result.HitStopSeconds > 0f)
            {
                BeginImpactFreeze(result.HitStopSeconds);
                if (request?.Action?.DeliveryMode == CombatDeliveryMode.MeleeHitbox)
                {
                    request.Attacker?.BeginImpactFreeze(result.HitStopSeconds * 0.82f);
                }
            }

            if (result.HpDamage > 0f)
            {
                bool damageNumbersEnabled = SettingsManager.Instance?.CurrentSettings?.DamageNumbersEnabled ?? true;
                if (damageNumbersEnabled)
                {
                    bool ice = request?.Profile?.DamageType == DamageType.Ice
                        || (request?.Profile?.ChillStacks ?? 0) > 0;
                    DamageNumberService.GetOrCreate(GetTree())?.ShowDamage(
                        this,
                        result.HpDamage,
                        result.Shattered,
                        ice,
                        result.WasBlocked);
                }
                EnemyHealthBarService.Instance?.NotifyDamaged(this);
            }

            CombatFeedbackService.GetOrCreate(GetTree())?.PlayHit(request?.Attacker, this, request, result, statusResult.FreezeStarted);

            EmitSignal(SignalName.HitResolved, result.HpDamage, result.WasBlocked, result.GuardBroken);
            OnHitReceived(request, result);

            if (result.Killed)
            {
                HandleDefeat(request.Attacker);
            }

            return result;
        }

        private bool TryPerfectParry(HitRequest request, out HitResult result)
        {
            result = null;
            WeaponMovesetData moveset = ActiveMoveset;
            CombatCharacter attacker = request?.Attacker;
            CombatActionData action = request?.Action;

            bool parryableMelee = action != null
                && action.DeliveryMode == CombatDeliveryMode.MeleeHitbox
                && (action.Tags & CombatActionTag.Uninterruptible) == CombatActionTag.None;
            if (request?.Target != this
                || request.Profile == null
                || moveset?.PerfectParryEnabled != true
                || _parryWindowRemaining <= 0f
                || !parryableMelee
                || attacker == null
                || !attacker.IsAlive
                || !FactionRules.CanDamage(attacker.Faction, Faction)
                || !IsBlockingAttackFrom(request.HitOrigin))
            {
                return false;
            }

            _parryWindowRemaining = 0f;
            _counterAttackWindowRemaining = Mathf.Max(
                _counterAttackWindowRemaining,
                Mathf.Max(0f, moveset.CounterAttackWindowSeconds));

            if (Stats != null && moveset.ParryStaminaReward > 0f)
            {
                Stats.ChangeStamina(moveset.ParryStaminaReward);
            }

            attacker.Actions?.Cancel();
            if (attacker.StateMachine?.Current != CombatStateId.Dead)
            {
                attacker.StateMachine?.EnterStagger(Mathf.Max(0.08f, moveset.ParryStaggerSeconds));
            }

            float hitStop = Mathf.Max(0f, moveset.ParryHitStopSeconds);
            bool hitStopEnabled = SettingsManager.Instance?.CurrentSettings?.HitStopEnabled ?? true;
            if (hitStopEnabled && hitStop > 0f)
            {
                BeginImpactFreeze(hitStop);
                attacker.BeginImpactFreeze(hitStop);
            }
            else if (!hitStopEnabled)
            {
                hitStop = 0f;
            }

            Vector2 incomingDirection = request.AttackDirection.LengthSquared() > 0.001f
                ? request.AttackDirection.Normalized()
                : (CombatCenter - attacker.CombatCenter).Normalized();
            CombatFeedbackService.GetOrCreate(GetTree())?
                .PlayParry(CombatCenter, incomingDirection);

            result = new HitResult
            {
                Applied = true,
                RejectionReason = HitRejectionReason.None,
                RawDamage = 0f,
                HpDamage = 0f,
                GuardDamage = 0f,
                PoiseDamage = 0f,
                WasBlocked = true,
                WasParried = true,
                GuardBroken = false,
                Staggered = false,
                Killed = false,
                Shattered = false,
                HitstunSeconds = 0f,
                ForcedStaggerSeconds = 0f,
                HitStopSeconds = hitStop,
                HitFlashSeconds = 0f,
                LaunchHeight = 0f,
                LaunchDuration = 0.05f,
                Knockback = Vector2.Zero
            };

            EmitSignal(SignalName.HitResolved, 0f, true, false);
            OnHitReceived(request, result);
            return true;
        }

        public void BeginImpactFreeze(float seconds)
        {
            if (seconds <= 0f || StateMachine?.Current == CombatStateId.Dead)
            {
                return;
            }

            _impactFreezeRemaining = Mathf.Max(_impactFreezeRemaining, seconds);
            if (_body != null && !_bodySpeedFrozen)
            {
                _storedBodySpeedScale = _body.SpeedScale;
                _body.SpeedScale = 0f;
                _bodySpeedFrozen = true;
            }
        }

        public void ResetCombatRuntime()
        {
            Actions?.Cancel();
            _combatHitbox?.DisableHitbox();
            _moveCommand = Vector2.Zero;
            _runCommand = false;
            _isActuallyRunning = false;
            _moveSpeedScale = 1f;
            _preserveFacingWhileMoving = false;
            _blockCommand = false;
            _parryWindowRemaining = 0f;
            _counterAttackWindowRemaining = 0f;
            _isExhausted = false;
            _locomotionVelocity = Vector2.Zero;
            _externalVelocity = Vector2.Zero;
            Velocity = Vector2.Zero;
            Statuses?.Clear();
            _impactFreezeRemaining = 0f;
            _hitFlashRemaining = 0f;
            _launchRemaining = 0f;
            RestoreBodyPresentation();

            bool alive = Stats == null || Stats.CurrentHP > 0f;
            _defeatHandled = !alive;
            if (alive)
            {
                StateMachine?.Reset();
                PlayIdleFrame();
            }
            else
            {
                StateMachine?.EnterDead();
            }

            ProcessMode = ProcessModeEnum.Inherit;
            SetPhysicsProcess(alive || !RemoveFromWorldOnDeath);
        }

        protected virtual void UpdateControlSource(float delta)
        {
        }

        protected virtual void OnCombatReady()
        {
        }

        protected virtual void OnCombatExitTree()
        {
        }

        protected virtual void OnHitReceived(HitRequest request, HitResult result)
        {
        }

        protected virtual void OnDefeated(CombatCharacter attacker)
        {
        }

        protected virtual float GetRuntimeMoveSpeedMultiplier()
        {
            return 1f;
        }


        private void OnActionEventTriggered(
            CombatActionData action,
            CombatActionEventData actionEvent,
            Vector2 direction)
        {
            CombatActionEventDispatcher.Dispatch(this, action, actionEvent, direction);
        }

        private void OnActionReleased(CombatActionData action, Vector2 direction)
        {
            // Resource cũ chưa có Events vẫn chạy được. Action mới có event sẽ không đi qua
            // legacy bridge, tránh spawn hai projectile từ một lần release.
            CombatActionEventDispatcher.DispatchLegacyDelivery(this, action, direction);
        }

        private void ResolveCoreNodes()
        {
            Stats = ResolveNode<PlayerStats>(StatsPath, "PlayerStats");
            Equipment = ResolveNode<EquipmentManager>(EquipmentPath, "EquipmentManager");
            _hurtbox = ResolveNode<Area2D>(HurtboxPath, "Hurtbox");
            _hurtboxShape = ResolveHurtboxShape(_hurtbox);
            _weaponSprite = ResolveNode<AnimatedSprite2D>(WeaponSpritePath, "WeaponSprite");
            ResolveBodySprite();

            if (_hurtbox != null)
            {
                // Hurtbox chỉ cần được hitbox khác nhìn thấy. Nó không cần tự quét Area khác.
                // Giữ Monitoring = false còn giúp giảm query thừa và tránh callback chồng chéo.
                _hurtbox.Monitoring = false;
                _hurtbox.Monitorable = true;
            }
        }


        private static CollisionShape2D ResolveHurtboxShape(Area2D hurtbox)
        {
            if (hurtbox == null)
            {
                return null;
            }

            foreach (Node child in hurtbox.GetChildren())
            {
                if (child is CollisionShape2D shape)
                {
                    return shape;
                }
            }

            return null;
        }

        private T ResolveNode<T>(NodePath configuredPath, string fallbackName) where T : Node
        {
            string path = configuredPath.ToString();
            if (!string.IsNullOrWhiteSpace(path))
            {
                T configured = GetNodeOrNull<T>(path);
                if (configured != null)
                {
                    return configured;
                }
            }

            return GetNodeOrNull<T>(fallbackName);
        }

        private void ResolveBodySprite()
        {
            string path = BodyPath.ToString();
            if (string.IsNullOrWhiteSpace(path))
            {
                path = "Body";
            }

            _body = GetNodeOrNull<AnimatedSprite2D>(path);
            if (_body != null)
            {
                BodyPath = new NodePath(path);
                return;
            }

            PackedScene bodyScene = Stats?.ConfigData?.BodyScene;
            if (bodyScene == null)
            {
                GD.PrintErr($"[{GetType().Name}] Không tìm thấy Body và CharacterConfig cũng không có BodyScene.");
                return;
            }

            Node bodyNode = bodyScene.Instantiate();
            if (bodyNode is not AnimatedSprite2D bodySprite)
            {
                GD.PrintErr($"[{GetType().Name}] BodyScene phải có root AnimatedSprite2D.");
                bodyNode.QueueFree();
                return;
            }

            bodySprite.Name = "Body";
            _body = bodySprite;
            BodyPath = new NodePath("Body");
            // Player có thể phải dựng BodyScene ngay trong _Ready. AddChild trực tiếp lúc này
            // đôi khi bị Godot từ chối vì parent đang setup children.
            CallDeferred("add_child", bodySprite);
        }

        private void SynchronizeBlocking()
        {
            if (!IsAlive || StateMachine.Current == CombatStateId.Dead)
            {
                _blockCommand = false;
                return;
            }

            if (_blockCommand && Actions?.IsRunning != true && StateMachine.CanStartBlock)
            {
                StateMachine.TryBeginBlock();
            }
            else if (!_blockCommand)
            {
                StateMachine.EndBlock();
            }
        }

        private void UpdateDefenseWindows(float delta)
        {
            float dt = Mathf.Max(0f, delta);
            _parryWindowRemaining = Mathf.Max(0f, _parryWindowRemaining - dt);
            _counterAttackWindowRemaining = Mathf.Max(0f, _counterAttackWindowRemaining - dt);
        }

        private void UpdateMovement(float delta)
        {
            bool hasInput = _moveCommand != Vector2.Zero;
            bool canRun = false;
            float actionMoveMultiplier = Actions?.IsRunning == true
                ? Mathf.Clamp(Actions.CurrentAction?.MovementInputMultiplier ?? 0f, 0f, 1f)
                : 0f;
            bool canUseActionMovement = StateMachine.IsAttackState && actionMoveMultiplier > 0.001f;
            bool canUseMovementInput = StateMachine.CanMove || canUseActionMovement;

            if (Stats != null)
            {
                if (Stats.CurrentStamina <= 2f)
                {
                    _isExhausted = true;
                }
                else if (Stats.CurrentStamina >= MinStaminaToRun)
                {
                    _isExhausted = false;
                }
            }

            if (StateMachine.CanMove && hasInput && _runCommand && !_isExhausted)
            {
                float cost = RunStaminaCost * delta;
                canRun = Stats == null || Stats.ConsumeStamina(cost);
            }
            _isActuallyRunning = canRun;

            Vector2 targetVelocity = Vector2.Zero;
            if (canUseMovementInput && hasInput)
            {
                float moveSpeed = canRun ? RunSpeed : Speed;
                if (canUseActionMovement)
                {
                    moveSpeed *= actionMoveMultiplier;
                }
                if (StateMachine.Current == CombatStateId.Blocking)
                {
                    moveSpeed *= ActiveMoveset?.GuardMoveSpeedMultiplier ?? 0.35f;
                }

                moveSpeed *= Abilities?.MoveSpeedMultiplier ?? 1f;
                moveSpeed *= Statuses?.MoveSpeedMultiplier ?? 1f;
                moveSpeed *= GetRuntimeMoveSpeedMultiplier();
                moveSpeed *= _moveSpeedScale;
                targetVelocity = _moveCommand * moveSpeed;
                if (!_preserveFacingWhileMoving)
                {
                    _facingCardinal = ResolveCardinalDirection(_moveCommand);
                }
            }

            float step = (targetVelocity == Vector2.Zero ? Deceleration : Acceleration) * delta;
            _locomotionVelocity = _locomotionVelocity.MoveToward(targetVelocity, step);
            _externalVelocity = _externalVelocity.MoveToward(Vector2.Zero, ExternalForceDecay * delta);

            if (_locomotionVelocity.LengthSquared() < 0.5f)
            {
                _locomotionVelocity = Vector2.Zero;
            }

            Vector2 actionVelocity = Actions?.MovementVelocity ?? Vector2.Zero;
            Velocity = _locomotionVelocity + actionVelocity + _externalVelocity;
        }

        private void UpdateLevelBoundsCache(float delta)
        {
            if (!KeepInsideLevelBounds || GetTree() == null)
            {
                _hasLevelBounds = false;
                return;
            }

            _levelBoundsRefreshRemaining -= Mathf.Max(0f, delta);
            Node sceneRoot = GetTree().CurrentScene;
            ulong sceneId = sceneRoot != null && GodotObject.IsInstanceValid(sceneRoot)
                ? sceneRoot.GetInstanceId()
                : 0UL;

            if (_levelBoundsRefreshRemaining > 0f && sceneId == _levelBoundsSceneId)
            {
                return;
            }

            _levelBoundsRefreshRemaining = Mathf.Max(0.1f, LevelBoundsRefreshSeconds);
            _levelBoundsSceneId = sceneId;

            GameLevel level = sceneRoot as GameLevel ?? FindGameLevel(sceneRoot);
            _hasLevelBounds = level != null && level.TryGetCameraBounds(out _levelBounds);
        }

        private void EnforceLevelBounds()
        {
            if (!KeepInsideLevelBounds || !_hasLevelBounds)
            {
                return;
            }

            Vector2 before = GlobalPosition;
            Vector2 clamped = ClampWorldPointToLevelBounds(before);
            if (clamped.IsEqualApprox(before))
            {
                return;
            }

            GlobalPosition = clamped;

            // Chỉ xóa velocity theo trục bị chặn để actor vẫn trượt dọc mép map tự nhiên.
            if (!Mathf.IsEqualApprox(clamped.X, before.X))
            {
                _locomotionVelocity.X = 0f;
                _externalVelocity.X = 0f;
                Velocity = new Vector2(0f, Velocity.Y);
            }
            if (!Mathf.IsEqualApprox(clamped.Y, before.Y))
            {
                _locomotionVelocity.Y = 0f;
                _externalVelocity.Y = 0f;
                Velocity = new Vector2(Velocity.X, 0f);
            }
        }

        private static GameLevel FindGameLevel(Node node)
        {
            if (node == null)
            {
                return null;
            }

            if (node is GameLevel level)
            {
                return level;
            }

            foreach (Node child in node.GetChildren())
            {
                GameLevel found = FindGameLevel(child);
                if (found != null)
                {
                    return found;
                }
            }

            return null;
        }

        private void UpdateStatusVisualEffects()
        {
            bool shouldShowFreeze = IsAlive && Statuses?.IsFrozen == true;
            bool hasFreezeVfx = _freezeStatusVfx != null && GodotObject.IsInstanceValid(_freezeStatusVfx);

            if (shouldShowFreeze && !hasFreezeVfx)
            {
                var freezeVfx = new CombatFreezeVfx2D();
                freezeVfx.Initialize(this);
                AddChild(freezeVfx);
                _freezeStatusVfx = freezeVfx;
            }
            else if (!shouldShowFreeze && hasFreezeVfx)
            {
                _freezeStatusVfx.QueueFree();
                _freezeStatusVfx = null;
            }
        }

        private void UpdateImpactPresentation(float delta)
        {
            float dt = Mathf.Max(0f, delta);

            if (_impactFreezeRemaining > 0f)
            {
                _impactFreezeRemaining -= dt;
                if (_impactFreezeRemaining <= 0f)
                {
                    _impactFreezeRemaining = 0f;
                    if (_body != null && _bodySpeedFrozen)
                    {
                        _body.SpeedScale = Mathf.Max(0.01f, _storedBodySpeedScale);
                    }
                    _bodySpeedFrozen = false;
                }
            }

            if (_hitFlashRemaining > 0f)
            {
                _hitFlashRemaining -= dt;
            }

            if (_launchRemaining > 0f && _body != null)
            {
                _launchRemaining -= dt;
                float progress = 1f - Mathf.Clamp(
                    _launchRemaining / Mathf.Max(0.05f, _launchDuration),
                    0f,
                    1f);
                float height = Mathf.Sin(progress * Mathf.Pi) * _launchHeight;
                _body.Position = _baseBodyPosition + new Vector2(0f, -height);
                if (_launchRemaining <= 0f)
                {
                    _launchRemaining = 0f;
                    _body.Position = _baseBodyPosition;
                }
            }

            UpdateBodyTint();
        }

        private void BeginHitFlash(float seconds)
        {
            _hitFlashRemaining = Mathf.Max(_hitFlashRemaining, Mathf.Max(0.02f, seconds));
            UpdateBodyTint();
        }

        private void StartVisualLaunch(float height, float duration)
        {
            if (_body == null)
            {
                return;
            }

            _launchHeight = Mathf.Max(_launchHeight, height);
            _launchDuration = Mathf.Max(0.08f, duration);
            _launchRemaining = _launchDuration;
        }

        private void UpdateBodyTint()
        {
            if (_body == null)
            {
                return;
            }

            if (_hitFlashRemaining > 0f)
            {
                _body.SelfModulate = new Color(1.7f, 1.7f, 1.7f, _baseBodySelfModulate.A);
            }
            else if (Statuses?.IsFrozen == true)
            {
                _body.SelfModulate = new Color(0.58f, 0.88f, 1f, _baseBodySelfModulate.A);
            }
            else if (Statuses?.HasChill == true)
            {
                _body.SelfModulate = new Color(0.82f, 0.94f, 1f, _baseBodySelfModulate.A);
            }
            else
            {
                _body.SelfModulate = _baseBodySelfModulate;
            }
        }

        private void RestoreBodyPresentation()
        {
            if (_body == null)
            {
                return;
            }

            if (_bodySpeedFrozen)
            {
                _body.SpeedScale = Mathf.Max(0.01f, _storedBodySpeedScale);
            }
            _bodySpeedFrozen = false;
            _body.Position = _baseBodyPosition;
            _body.SelfModulate = _baseBodySelfModulate;
        }

        private void UpdateAnimation()
        {
            if (_body == null || _body.SpriteFrames == null || !IsAlive)
            {
                return;
            }

            if (Actions?.IsRunning == true)
            {
                return;
            }

            if (StateMachine.Current == CombatStateId.Blocking || StateMachine.Current == CombatStateId.BlockStun)
            {
                PlayBlockAnimation();
                return;
            }

            if (StateMachine.IsForcedState)
            {
                return;
            }

            bool moving = _locomotionVelocity.LengthSquared() > 1f;
            if (moving)
            {
                // Khi backpedal/strafe, giữ animation theo hướng mặt thay vì hướng vận tốc.
                // Nhờ vậy Hyou lùi khỏi slime mà không quay lưng rồi vẫn gây damage.
                string direction = _preserveFacingWhileMoving
                    ? _facingCardinal
                    : ResolveEightDirection(_locomotionVelocity.Normalized());
                bool running = _isActuallyRunning && !_preserveFacingWhileMoving;
                string animation = $"{(running ? "run" : "go")}_{direction}";
                _lastMoveAnimation = animation;
                if (_body.SpriteFrames.HasAnimation(animation)
                    && (_body.Animation.ToString() != animation || !_body.IsPlaying()))
                {
                    _body.Play(animation);
                }
            }
            else if (_wasMoving || _body.IsPlaying())
            {
                PlayIdleFrame();
            }

            if (_weaponSprite != null)
            {
                _weaponSprite.Visible = false;
            }
        }

        private void PlayBlockAnimation()
        {
            string movesetAnimation = ActiveMoveset?.ResolveGuardAnimation(_facingCardinal) ?? string.Empty;
            string genericAnimation = $"block_{_facingCardinal}";
            string selected = !string.IsNullOrWhiteSpace(movesetAnimation)
                && _body.SpriteFrames.HasAnimation(movesetAnimation)
                    ? movesetAnimation
                    : genericAnimation;

            if (_body.SpriteFrames.HasAnimation(selected)
                && (_body.Animation.ToString() != selected || !_body.IsPlaying()))
            {
                _body.Play(selected);
            }
        }

        private void PlayIdleFrame()
        {
            if (_body == null || _body.SpriteFrames == null)
            {
                return;
            }

            string idle = $"go_{_facingCardinal}";
            if (!_body.SpriteFrames.HasAnimation(idle))
            {
                idle = _body.SpriteFrames.HasAnimation("idle") ? "idle" : "Idle";
            }

            if (_body.SpriteFrames.HasAnimation(idle))
            {
                _body.Animation = idle;
                int frameCount = _body.SpriteFrames.GetFrameCount(idle);
                _body.Frame = Mathf.Clamp(StopFrameIndex, 0, Mathf.Max(0, frameCount - 1));
                _body.Stop();
            }
        }

        private void OnWeaponVisualChanged(PackedScene weaponScene)
        {
            if (_weaponSprite == null)
            {
                return;
            }

            if (weaponScene == null)
            {
                _weaponSprite.SpriteFrames = null;
                _weaponSprite.Visible = false;
                return;
            }

            Node instance = weaponScene.Instantiate();
            if (instance is AnimatedSprite2D source)
            {
                _weaponSprite.SpriteFrames = source.SpriteFrames;
                _weaponSprite.Visible = false;
            }

            instance.QueueFree();
        }

        private void OnBodyFrameChanged()
        {
            Actions?.HandleBodyFrameChanged();
        }

        private void OnBodyAnimationFinished()
        {
            Actions?.HandleBodyAnimationFinished();
        }

        private void OnCombatStateChanged(CombatStateId previous, CombatStateId current)
        {
            if (current == CombatStateId.Dead)
            {
                _combatHitbox?.DisableHitbox();
                _locomotionVelocity = Vector2.Zero;
                Velocity = Vector2.Zero;
            }
        }

        private void OnStatsDefeated()
        {
            // ApplyDamage phát signal đồng bộ ngay giữa CombatResolver. Khi đó ReceiveHit vẫn chưa
            // nhận HitResult và chưa biết killer. Để ReceiveHit xử lý một lần duy nhất.
            if (_isResolvingHit)
            {
                return;
            }

            if (StateMachine?.Current != CombatStateId.Dead)
            {
                Actions?.Cancel();
                Abilities?.CancelActiveEffects();
                StateMachine?.EnterDead();
                HandleDefeat(null);
            }
        }

        private void HandleDefeat(CombatCharacter attacker)
        {
            if (_defeatHandled)
            {
                return;
            }

            _defeatHandled = true;
            EmitSignal(SignalName.Defeated, attacker);
            OnDefeated(attacker);
            if (RemoveFromWorldOnDeath)
            {
                CallDeferred("queue_free");
            }
        }

        private void ConfigureFactionGroups()
        {
            switch (Faction)
            {
                case CombatFaction.Player:
                    AddToGroup("Player");
                    break;
                case CombatFaction.Companion:
                    AddToGroup("Companion");
                    break;
                case CombatFaction.Enemy:
                    AddToGroup("Enemy");
                    break;
            }
        }

        private static string ResolveCardinalDirection(Vector2 direction)
        {
            if (Mathf.Abs(direction.X) > Mathf.Abs(direction.Y))
            {
                return direction.X >= 0f ? "right" : "left";
            }

            return direction.Y >= 0f ? "down" : "up";
        }

        private string ResolveEightDirection(Vector2 direction)
        {
            string vertical = direction.Y > 0.2f ? "down" : (direction.Y < -0.2f ? "up" : string.Empty);
            string horizontal = direction.X > 0.2f ? "right" : (direction.X < -0.2f ? "left" : string.Empty);
            if (string.IsNullOrEmpty(vertical) && string.IsNullOrEmpty(horizontal))
            {
                return _facingCardinal;
            }

            return !string.IsNullOrEmpty(vertical) && !string.IsNullOrEmpty(horizontal)
                ? $"{vertical}_{horizontal}"
                : $"{vertical}{horizontal}";
        }

        private static Vector2 DirectionToVector(string direction)
        {
            return direction switch
            {
                "up" => Vector2.Up,
                "left" => Vector2.Left,
                "right" => Vector2.Right,
                _ => Vector2.Down
            };
        }
    }
}
