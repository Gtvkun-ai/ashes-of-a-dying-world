using Godot;
using AshesofaDyingWorld.Entities.Player;
using AshesofaDyingWorld.Combat.Actors;
using AshesofaDyingWorld.Combat.Runtime;
using AshesofaDyingWorld.Core.Data;
using System.Collections.Generic;
using System;

namespace AshesofaDyingWorld.UI.HUD
{
    public partial class CharacterUnitHUD : PanelContainer
    {
        public event Action<PlayerStats> ContextMenuRequested;

        private PlayerStats _targetStats;
        private Player _targetPlayer;

        [Export] public TextureProgressBar HealthBar;
        [Export] public TextureProgressBar ManaBar;
        [Export] public TextureProgressBar StaminaBar;
        [Export] public Label NameLabel;
        [Export] public TextureRect Portrait;
        
        private TextureRect frameBackground;
        private ShaderMaterial shaderMaterial;
        private const string ShaderPath = "res://assets/shaders/outline.gdshader";
        private const string StatusEffectFrameTexturePath = "res://assets/graphics/ui/hud/status_effects/status_effect_icon_frame.png";
        private const string ChillStatusIconPath = "res://assets/graphics/ui/hud/status_effects/icons/chill.png";
        private const string SlowStatusIconPath = "res://assets/graphics/ui/hud/status_effects/icons/slow.png";
        private const string FrozenStatusIconPath = "res://assets/graphics/ui/hud/status_effects/icons/frozen.png";
        private const float StatusEffectBadgeSize = 28.0f;
        private const float StatusEffectIconInset = 4.0f;
        private const float StatusEffectBadgeSpacing = 4.0f;
        private Control _activeSkillStrip;
        private Control _combatStatusStrip;
        private Texture2D _statusEffectFrameTexture;
        private Texture2D _chillStatusIconTexture;
        private Texture2D _slowStatusIconTexture;
        private Texture2D _frozenStatusIconTexture;
        private CombatCharacter _targetCombatant;
        private CombatStatusBadgeView _chillStatusBadge;
        private CombatStatusBadgeView _slowStatusBadge;
        private CombatStatusBadgeView _frozenStatusBadge;
        private readonly List<SkillBadgeView> _skillBadgeViews = new();
        private Control _contextHitTarget;

        public PlayerStats TargetStats => _targetStats;

        private sealed class SkillBadgeView
        {
            public SkillData Skill;
            public Control Holder;
            public TextureRect Icon;
            public ColorRect Overlay;
            public ColorRect OverlayEdge;
            public TextureRect Frame;
        }


        private sealed class CombatStatusBadgeView
        {
            public Control Holder;
            public Label StackLabel;
        }
        public override void _Ready()
        {
            if(Portrait == null)
            {
                Portrait = GetNode<TextureRect>("TextureRect/Portrait");
            }

            // Lấy TextureRect đã có trong scene (background frame)
            frameBackground = GetNode<TextureRect>("TextureRect");
            
            // Load shader và áp dụng vào frameBackground
            var shader = GD.Load<Shader>(ShaderPath);
            if (shader != null && frameBackground != null)
            {
                shaderMaterial = new ShaderMaterial();
                shaderMaterial.Shader = shader;
                frameBackground.Material = shaderMaterial;
                
                shaderMaterial.SetShaderParameter("line_thickness", 0.0f);
                shaderMaterial.SetShaderParameter("line_color", new Color(1.0f, 1.0f, 1.0f, 1.0f));                
            }
            else
            {
                GD.PrintErr($"[CharacterUnitHUD] Shader or frameBackground not found");
            }

            LoadStatusEffectFrameTexture();
            SetupActiveSkillStrip();
            SetupCombatStatusStrip();
            if (frameBackground != null)
            {
                frameBackground.Resized += OnFrameBackgroundResized;
            }
            UpdateActiveSkillStripPlacement();
            UpdateCombatStatusStripPlacement();
            SetupContextHitTarget();
        }

        public override void _Process(double delta)
        {
            UpdateActiveSkillStripPlacement();
            UpdateCombatStatusStripPlacement();

            if (!Visible || _targetStats == null)
            {
                return;
            }

            UpdateSkillOverlayState();
            UpdateCombatStatusState();
        }

        public void SetTarget(PlayerStats stats)
        {
            if (_targetStats != null)
                _targetStats.StatsChanged -= UpdateUI;

            _targetStats = stats;
            _targetPlayer = null;
            _targetCombatant = null;
            if (_targetStats != null)
            {
                _targetStats.StatsChanged += UpdateUI;

                if (stats.ConfigData != null)
                {
                    if (NameLabel != null)
                        NameLabel.Text = stats.ConfigData.Name;
                    
                    if (Portrait != null && stats.ConfigData.Icon != null)
                        Portrait.Texture = stats.ConfigData.Icon;
                }

                RebuildActiveSkillStrip();
                UpdateCombatStatusState();
                UpdateUI();
            }
            else
            {
                RebuildActiveSkillStrip();
                UpdateCombatStatusState();
            }
        }

        private void UpdateUI()
        {
            if (_targetStats == null) return;

            if (HealthBar != null)
            {
                HealthBar.MaxValue = _targetStats.MaxHP; 
                HealthBar.Value = _targetStats.CurrentHP;
            }

            if (ManaBar != null)
            {
                ManaBar.MaxValue = _targetStats.MaxMP;
                ManaBar.Value = _targetStats.CurrentMP;
            }

            if (StaminaBar != null)
            {
                StaminaBar.MaxValue = _targetStats.MaxStamina; 
                StaminaBar.Value = _targetStats.CurrentStamina;
            }

            UpdateSkillOverlayState();
            UpdateCombatStatusState();
        }

        public void ApplyHighlight(bool isSelected)
        {
            if (shaderMaterial != null)
            {
                shaderMaterial.SetShaderParameter("line_thickness", isSelected ? 20.0f : 0.0f);
            }
        }
        
        public override void _ExitTree()
        {
            if (_targetStats != null)
                _targetStats.StatsChanged -= UpdateUI;

            if (frameBackground != null)
                frameBackground.Resized -= OnFrameBackgroundResized;

            if (_contextHitTarget != null)
                _contextHitTarget.GuiInput -= OnContextGuiInput;
        }


        private void SetupContextHitTarget()
        {
            if (_contextHitTarget != null)
            {
                return;
            }

            _contextHitTarget = new Control
            {
                Name = "ContextHitTarget",
                MouseFilter = MouseFilterEnum.Pass,
                MouseDefaultCursorShape = CursorShape.PointingHand
            };
            _contextHitTarget.GuiInput += OnContextGuiInput;
            AddChild(_contextHitTarget);
            _contextHitTarget.SetAnchorsAndOffsetsPreset(LayoutPreset.FullRect);
            MoveChild(_contextHitTarget, GetChildCount() - 1);
        }

        private void OnContextGuiInput(InputEvent inputEvent)
        {
            if (inputEvent is not InputEventMouseButton mouse
                || mouse.ButtonIndex != MouseButton.Right
                || !mouse.Pressed
                || _targetStats == null)
            {
                return;
            }

            ContextMenuRequested?.Invoke(_targetStats);
            GetViewport()?.SetInputAsHandled();
        }

        private void LoadStatusEffectFrameTexture()
        {
            // Khung/icon effect load mềm; thiếu asset thì HUD vẫn chạy, chỉ mất phần trang trí tương ứng.
            _statusEffectFrameTexture = GD.Load<Texture2D>(StatusEffectFrameTexturePath);
            _chillStatusIconTexture = GD.Load<Texture2D>(ChillStatusIconPath);
            _slowStatusIconTexture = GD.Load<Texture2D>(SlowStatusIconPath);
            _frozenStatusIconTexture = GD.Load<Texture2D>(FrozenStatusIconPath);
        }

        private void SetupCombatStatusStrip()
        {
            if (_combatStatusStrip != null)
            {
                return;
            }

            _combatStatusStrip = new Control
            {
                Name = "CombatStatusStrip",
                Visible = false,
                MouseFilter = MouseFilterEnum.Ignore
            };
            _combatStatusStrip.SetAnchorsPreset(LayoutPreset.TopLeft);
            AddChild(_combatStatusStrip);

            _chillStatusBadge = CreateCombatStatusBadge(_chillStatusIconTexture, true, "Chill");
            _slowStatusBadge = CreateCombatStatusBadge(_slowStatusIconTexture, false, "Slow");
            _frozenStatusBadge = CreateCombatStatusBadge(_frozenStatusIconTexture, false, "Frozen");
        }

        private CombatStatusBadgeView CreateCombatStatusBadge(Texture2D iconTexture, bool showStack, string tooltip)
        {
            var holder = new Control
            {
                Visible = false,
                CustomMinimumSize = new Vector2(StatusEffectBadgeSize, StatusEffectBadgeSize),
                Size = new Vector2(StatusEffectBadgeSize, StatusEffectBadgeSize),
                MouseFilter = MouseFilterEnum.Ignore,
                TooltipText = tooltip
            };
            _combatStatusStrip.AddChild(holder);

            var background = new ColorRect
            {
                Color = new Color(0.06f, 0.04f, 0.03f, 0.86f),
                MouseFilter = MouseFilterEnum.Ignore,
                Position = new Vector2(StatusEffectIconInset, StatusEffectIconInset),
                Size = new Vector2(
                    StatusEffectBadgeSize - StatusEffectIconInset * 2f,
                    StatusEffectBadgeSize - StatusEffectIconInset * 2f)
            };
            holder.AddChild(background);

            var icon = new TextureRect
            {
                Texture = iconTexture,
                ExpandMode = TextureRect.ExpandModeEnum.IgnoreSize,
                StretchMode = TextureRect.StretchModeEnum.KeepAspectCentered,
                MouseFilter = MouseFilterEnum.Ignore,
                Position = new Vector2(StatusEffectIconInset - 1f, StatusEffectIconInset - 1f),
                Size = new Vector2(
                    StatusEffectBadgeSize - (StatusEffectIconInset - 1f) * 2f,
                    StatusEffectBadgeSize - (StatusEffectIconInset - 1f) * 2f)
            };
            holder.AddChild(icon);

            if (_statusEffectFrameTexture != null)
            {
                var frame = new TextureRect
                {
                    Texture = _statusEffectFrameTexture,
                    ExpandMode = TextureRect.ExpandModeEnum.IgnoreSize,
                    StretchMode = TextureRect.StretchModeEnum.Scale,
                    MouseFilter = MouseFilterEnum.Ignore,
                    Size = new Vector2(StatusEffectBadgeSize, StatusEffectBadgeSize)
                };
                holder.AddChild(frame);
            }

            Label stackLabel = null;
            if (showStack)
            {
                stackLabel = new Label
                {
                    HorizontalAlignment = HorizontalAlignment.Right,
                    VerticalAlignment = VerticalAlignment.Bottom,
                    MouseFilter = MouseFilterEnum.Ignore,
                    Size = new Vector2(StatusEffectBadgeSize - 2f, StatusEffectBadgeSize - 2f),
                    Visible = false
                };
                stackLabel.AddThemeFontSizeOverride("font_size", 9);
                stackLabel.AddThemeColorOverride("font_color", Colors.White);
                stackLabel.AddThemeColorOverride("font_outline_color", Colors.Black);
                stackLabel.AddThemeConstantOverride("outline_size", 2);
                holder.AddChild(stackLabel);
            }

            return new CombatStatusBadgeView
            {
                Holder = holder,
                StackLabel = stackLabel
            };
        }

        private void UpdateCombatStatusState()
        {
            if (_combatStatusStrip == null)
            {
                return;
            }

            _targetCombatant ??= ResolveCombatantForStats(_targetStats);
            CombatStatusController statuses = _targetCombatant?.Statuses;

            bool frozen = statuses?.IsFrozen == true;
            bool chill = !frozen && statuses?.HasChill == true;
            bool slow = !frozen && statuses?.IsSlowed == true;

            int visibleIndex = 0;
            SetCombatStatusBadgeVisible(_chillStatusBadge, chill, ref visibleIndex);
            SetCombatStatusBadgeVisible(_slowStatusBadge, slow, ref visibleIndex);
            SetCombatStatusBadgeVisible(_frozenStatusBadge, frozen, ref visibleIndex);

            if (_chillStatusBadge?.StackLabel != null)
            {
                int stacks = statuses?.ChillStacks ?? 0;
                _chillStatusBadge.StackLabel.Text = stacks > 1 ? stacks.ToString() : string.Empty;
                _chillStatusBadge.StackLabel.Visible = chill && stacks > 1;
            }

            _combatStatusStrip.Visible = visibleIndex > 0;
        }

        private static void SetCombatStatusBadgeVisible(CombatStatusBadgeView badge, bool visible, ref int index)
        {
            if (badge?.Holder == null)
            {
                return;
            }

            badge.Holder.Visible = visible;
            if (!visible)
            {
                return;
            }

            badge.Holder.Position = new Vector2(index * (StatusEffectBadgeSize + StatusEffectBadgeSpacing), 0f);
            index++;
        }

        private void SetupActiveSkillStrip()
        {
            if (_activeSkillStrip != null)
            {
                return;
            }

            _activeSkillStrip = new Control();
            _activeSkillStrip.Name = "ActiveSkillStrip";
            _activeSkillStrip.Visible = false;
            _activeSkillStrip.MouseFilter = MouseFilterEnum.Ignore;
            _activeSkillStrip.SetAnchorsPreset(LayoutPreset.TopLeft);
            AddChild(_activeSkillStrip);
        }

        private void RebuildActiveSkillStrip()
        {
            SetupActiveSkillStrip();

            foreach (Node child in _activeSkillStrip.GetChildren())
            {
                child.QueueFree();
            }

            _skillBadgeViews.Clear();

            var skills = _targetStats?.ConfigData?.ActiveSkills;
            if (skills == null || skills.Count == 0)
            {
                _activeSkillStrip.Visible = false;
                return;
            }

            foreach (var skill in skills)
            {
                if (skill == null)
                {
                    continue;
                }

                // Khung icon effect dùng texture riêng để cùng ngôn ngữ thiết kế với HUD.
                var badge = new Control();
                badge.Visible = false;
                badge.CustomMinimumSize = new Vector2(StatusEffectBadgeSize, StatusEffectBadgeSize);
                badge.MouseFilter = MouseFilterEnum.Ignore;
                badge.SetAnchorsPreset(LayoutPreset.TopLeft);
                badge.Size = new Vector2(StatusEffectBadgeSize, StatusEffectBadgeSize);
                _activeSkillStrip.AddChild(badge);

                var clipRoot = new Control();
                clipRoot.Name = "ClipRoot";
                clipRoot.SetAnchorsPreset(LayoutPreset.FullRect);
                clipRoot.OffsetLeft = StatusEffectIconInset;
                clipRoot.OffsetTop = StatusEffectIconInset;
                clipRoot.OffsetRight = -StatusEffectIconInset;
                clipRoot.OffsetBottom = -StatusEffectIconInset;
                clipRoot.MouseFilter = MouseFilterEnum.Ignore;
                clipRoot.ClipContents = true;
                badge.AddChild(clipRoot);

                var iconBackground = new ColorRect();
                iconBackground.MouseFilter = MouseFilterEnum.Ignore;
                iconBackground.Color = new Color(0.10f, 0.05f, 0.02f, 0.92f);
                iconBackground.SetAnchorsPreset(LayoutPreset.FullRect);
                clipRoot.AddChild(iconBackground);

                var iconCenter = new CenterContainer();
                iconCenter.SetAnchorsPreset(LayoutPreset.FullRect);
                iconCenter.MouseFilter = MouseFilterEnum.Ignore;
                clipRoot.AddChild(iconCenter);

                var icon = CreateAutoSizedSkillIcon(skill.Icon, 16.0f, 16.0f);
                iconCenter.AddChild(icon);

                // Overlay tối chạy từ trên xuống, biểu diễn phần thời gian đã trôi qua.
                var overlay = new ColorRect();
                overlay.MouseFilter = MouseFilterEnum.Ignore;
                overlay.Color = new Color(0.02f, 0.01f, 0.00f, 0.58f);
                clipRoot.AddChild(overlay);

                // Viền mảnh màu vàng ở mép overlay để nhìn rõ nhịp tụt thời gian.
                var overlayEdge = new ColorRect();
                overlayEdge.MouseFilter = MouseFilterEnum.Ignore;
                overlayEdge.Color = new Color(0.90f, 0.73f, 0.36f, 0.95f);
                clipRoot.AddChild(overlayEdge);

                var frame = new TextureRect();
                frame.MouseFilter = MouseFilterEnum.Ignore;
                frame.Texture = _statusEffectFrameTexture;
                frame.ExpandMode = TextureRect.ExpandModeEnum.IgnoreSize;
                frame.StretchMode = TextureRect.StretchModeEnum.Scale;
                frame.SetAnchorsPreset(LayoutPreset.FullRect);
                badge.AddChild(frame);

                badge.TooltipText = string.IsNullOrWhiteSpace(skill.SkillName) ? "Hiệu ứng kỹ năng" : skill.SkillName;
                _skillBadgeViews.Add(new SkillBadgeView
                {
                    Skill = skill,
                    Holder = badge,
                    Icon = icon,
                    Overlay = overlay,
                    OverlayEdge = overlayEdge,
                    Frame = frame
                });
            }
        }

        private void UpdateSkillOverlayState()
        {
            if (_activeSkillStrip == null || _skillBadgeViews.Count == 0)
            {
                return;
            }

            _targetPlayer ??= ResolvePlayerForStats(_targetStats);

            SkillData activeSkill = _targetPlayer?.GetActiveTimedSkill();
            float duration = _targetPlayer != null ? Mathf.Max(0.01f, _targetPlayer.GetActiveTimedSkillDuration()) : 0.0f;
            float remaining = _targetPlayer != null ? _targetPlayer.GetActiveTimedSkillRemaining() : 0.0f;
            float overlayRatio = (activeSkill != null && remaining > 0.0f && duration > 0.0f)
                ? Mathf.Clamp(1.0f - (remaining / duration), 0.0f, 1.0f)
                : 0.0f;
            bool hasVisibleBadge = false;
            int visibleIndex = 0;

            foreach (var badgeView in _skillBadgeViews)
            {
                if (badgeView?.Holder == null || badgeView.Overlay == null || badgeView.OverlayEdge == null)
                {
                    continue;
                }

                bool isVisible = badgeView.Skill == activeSkill && activeSkill != null && remaining > 0.0f;
                badgeView.Holder.Visible = isVisible;
                if (!isVisible)
                {
                    badgeView.Overlay.Visible = false;
                    badgeView.OverlayEdge.Visible = false;
                    continue;
                }

                hasVisibleBadge = true;
                badgeView.Holder.Position = new Vector2(visibleIndex * (StatusEffectBadgeSize + StatusEffectBadgeSpacing), 0.0f);
                visibleIndex++;

                Vector2 badgeSize = badgeView.Overlay.GetParent<Control>().Size;
                float overlayHeight = badgeSize.Y * overlayRatio;

                badgeView.Overlay.Visible = overlayHeight > 0.5f;
                badgeView.Overlay.Position = Vector2.Zero;
                badgeView.Overlay.Size = new Vector2(badgeSize.X, overlayHeight);

                bool showEdge = overlayRatio > 0.02f && overlayRatio < 1.0f;
                badgeView.OverlayEdge.Visible = showEdge;
                if (showEdge)
                {
                    float edgeY = Mathf.Clamp(overlayHeight - 1.0f, 0.0f, Mathf.Max(0.0f, badgeSize.Y - 2.0f));
                    badgeView.OverlayEdge.Position = new Vector2(0.0f, edgeY);
                    badgeView.OverlayEdge.Size = new Vector2(badgeSize.X, 2.0f);
                }
            }

            _activeSkillStrip.Visible = hasVisibleBadge;
        }

        private void UpdateActiveSkillStripPlacement()
        {
            if (_activeSkillStrip == null)
            {
                return;
            }

            float top = frameBackground != null ? frameBackground.Size.Y - 2.0f : 98.0f;
            _activeSkillStrip.OffsetLeft = 8.0f;
            _activeSkillStrip.OffsetTop = top;
            _activeSkillStrip.OffsetRight = 180.0f;
            _activeSkillStrip.OffsetBottom = top + StatusEffectBadgeSize + 2.0f;
        }

        private void UpdateCombatStatusStripPlacement()
        {
            if (_combatStatusStrip == null)
            {
                return;
            }

            float top = frameBackground != null ? frameBackground.Size.Y - 2.0f : 98.0f;
            _combatStatusStrip.OffsetLeft = 196.0f;
            _combatStatusStrip.OffsetTop = top;
            _combatStatusStrip.OffsetRight = 292.0f;
            _combatStatusStrip.OffsetBottom = top + StatusEffectBadgeSize + 2.0f;
        }

        private void OnFrameBackgroundResized()
        {
            UpdateActiveSkillStripPlacement();
            UpdateCombatStatusStripPlacement();
        }

        private CombatCharacter ResolveCombatantForStats(PlayerStats stats)
        {
            if (stats == null || GetTree() == null)
            {
                return null;
            }

            foreach (Node node in GetTree().GetNodesInGroup("Combatant"))
            {
                if (node is CombatCharacter combatant && combatant.Stats == stats)
                {
                    return combatant;
                }
            }

            return null;
        }

        private Player ResolvePlayerForStats(PlayerStats stats)
        {
            if (stats == null || GetTree() == null)
            {
                return null;
            }

            foreach (Node node in GetTree().GetNodesInGroup("Player"))
            {
                if (node is Player player && player.GetStatsNode() == stats)
                {
                    return player;
                }
            }

            return null;
        }

        private TextureRect CreateAutoSizedSkillIcon(Texture2D texture, float maxWidth, float maxHeight)
        {
            var iconRect = new TextureRect();
            iconRect.MouseFilter = MouseFilterEnum.Ignore;
            iconRect.Texture = texture;
            iconRect.ExpandMode = TextureRect.ExpandModeEnum.IgnoreSize;
            iconRect.StretchMode = TextureRect.StretchModeEnum.KeepAspectCentered;
            iconRect.CustomMinimumSize = ComputeSafeSkillIconSize(texture, maxWidth, maxHeight);
            return iconRect;
        }

        private Vector2 ComputeSafeSkillIconSize(Texture2D texture, float maxWidth, float maxHeight)
        {
            if (texture == null)
            {
                return new Vector2(maxWidth, maxHeight);
            }

            Vector2 sourceSize = texture.GetSize();
            if (sourceSize.X <= 0.0f || sourceSize.Y <= 0.0f)
            {
                return new Vector2(maxWidth, maxHeight);
            }

            float scale = Mathf.Min(Mathf.Min(maxWidth / sourceSize.X, maxHeight / sourceSize.Y), 1.0f);
            float fittedWidth = Mathf.Max(10.0f, Mathf.Round(sourceSize.X * scale));
            float fittedHeight = Mathf.Max(10.0f, Mathf.Round(sourceSize.Y * scale));
            return new Vector2(fittedWidth, fittedHeight);
        }
    }
}
